import Chart from "./chart.js";
import Chart1 from "./river_chart.js";

let mapData = {}

let point_data = {state: 'New_York', year: 2019}

let interceptor = {
    set: function(recObj, key, value) {
        if(key === 'year'){
            sampleData = extractYearData(mapData, parseInt(value))
            console.log(key, 'is changed to', value)
            uStates.draw("#statesvg", sampleData, proxyPoint);
        }
        else if(key === 'state'){
            console.log(key, 'is changed to', value)
            d3.selectAll(".riverBox").remove()
            drawRiver()
        }
        recObj[key] = value
        return true
    }
}

let proxyPoint = new Proxy(point_data, interceptor)

d3.csv('./stacked_area_year.csv', function(d){
    let result = {}
    for(let item in d){
        if(item !== 'date') result[item] = Math.round((+d[item])/10000)
        else result[item] = d[item]
    } 
    return result
}).then(function(data){
    // console.log(data)
    let keyList = JSON.parse(JSON.stringify(data.columns))
    let index1 = keyList.indexOf('date')
    keyList.splice(index1, 1)
    let index2 = keyList.indexOf('total')
    keyList.splice(index2, 1)
    // console.log(keyList)
    /* ----------------------------配置参数------------------------  */
    const chart = new Chart();
    const config = {
        margins: {top: 30, left: 80, bottom: 50, right: 80},
        textColor: 'white',
        gridColor: 'white',
        ShowGridX: [],
        ShowGridY: [],
        pointSize: 3,
        pointColor: 'white',
        hoverColor: 'red',
        animateDuration: 1000
    }

    chart.margins(config.margins);
    
    /* ----------------------------尺度转换------------------------  */
    chart.scaleX = d3.scalePoint()
                    .domain(data.map((d) => d.date))
                    .range([0, chart.getBodyWidth()])
                    
    
    chart.scaleY = d3.scaleLinear()
                    .domain([0, (Math.floor((d3.max(data, (d) => d.total))/10) + 5)*12])
                    .range([chart.getBodyHeight(), 0])

    chart.stack = d3.stack()
                    .keys([...keyList])
                    .order(d3.stackOrderAscending)
                    .offset(d3.stackOffsetNone);

    
    /* ----------------------------渲染线条------------------------  */
    chart.renderLines = function(){

        let lines = chart.body().selectAll('.line')
                    .data(chart.stack(data));

            lines.enter()
                    .append('path')
                    .attr('class', (d) => 'line line-' + d.key)
                    .attr('fill', (d,i) => {
                        return chart._colors(i)
                    })
                .merge(lines)
                    .attr('fill', 'none')
                    .attr('stroke', (d,i) => {
                        return chart._colors(i)
                    })
                    .transition().duration(config.animateDuration)
                    .attrTween('d', lineTween);
            
            lines.exit()
                    .remove();
            
            //中间帧函数
            function lineTween(_d){
                if (!_d) return;
                const generateLine = d3.line()
                                        .x((d) => d[0])
                                        .y((d) => d[1]);

                const pointX = data.map((d) => chart.scaleX(d.date));
                const pointY = _d.map((d) => chart.scaleY(d[1]));

                const interpolate = getInterpolate(pointX, pointY);                
                
                const ponits = [];

                const interval = 1/(pointX.length-1);

                let index = 0;

                return function(t){
                    if (t - interval > 0 && t % interval < Math.pow(10, -1.4)){  //保证线条一定经过数据点
                        index = Math.floor(t / interval);
                        ponits.push([pointX[index], pointY[index]]);
                    }else{
                        ponits.push([interpolate.x(t), interpolate.y(t)]);
                    }
                    return generateLine(ponits);
                }
            }

            //点插值
            function getInterpolate(pointX, pointY){

                const domain = d3.range(0, 1, 1/(pointX.length-1));
                domain.push(1);

                const interpolateX = d3.scaleLinear()
                                        .domain(domain)
                                        .range(pointX);

                const interpolateY = d3.scaleLinear()
                                        .domain(domain)
                                        .range(pointY);
                return {
                    x: interpolateX,
                    y: interpolateY
                };

            }
    }

    /* ----------------------------渲染点------------------------  */
    chart.renderPonits = function(){

        chart.stack(data).forEach((pointData, i) => {
            // console.log(pointData)
            let ponits = chart.body().selectAll('.point-' + pointData.key)
                    .data(pointData);
            // console.log(ponits)
            
            ponits.enter()
                    .append('circle')
                    .attr('class',  (d) => {
                        let point_date = d.data.date
                        return 'point point-' + pointData.key + ' date-' + point_date
                    })
                .merge(ponits)
                    .attr('cx', (d) => chart.scaleX(d.data.date))
                    .attr('cy', (d) => chart.scaleY(d[1]))
                    .attr('r', 0)
                    .attr('fill', config.pointColor)
                    .attr('stroke', chart._colors(i))
                    .transition().duration(config.animateDuration)
                    .attr('r', config.pointSize)
                    .attr('value', (d) => pointData.key + ':' + d.data[pointData.key]);
        });
    };

    /* ----------------------------渲染面------------------------  */
    chart.renderArea = function(){
        const areas = chart.body().insert('g',':first-child')
                        .selectAll('.area')
                        .data(chart.stack(data));
              
              areas.enter()
                        .append('path')
                        .attr('class', (d) => 'area area-' + d.key)
                    .merge(areas)
                        .style('fill', (d,i) => chart._colors(i))
                        .transition().duration(config.animateDuration)
                        .attrTween('d', areaTween);

        //中间帧函数
        function areaTween(_d){
            if (!_d) return;
            const generateArea = d3.area()
                        .x((d) => d[0])
                        .y0((d) => d[1])
                        .y1((d) => d[2]);

            const pointX = data.map((d) => chart.scaleX(d.date));
            const pointY0 = _d.map((d) => chart.scaleY(d[0]));
            const pointY1 = _d.map((d) => chart.scaleY(d[1]));

            const interpolate = getAreaInterpolate(pointX, pointY0, pointY1);                
            
            const ponits = []

            return function(t){
                ponits.push([interpolate.x(t), interpolate.y0(t), interpolate.y1(t)]);
                return generateArea(ponits);
            }
        }

        //点插值
        function getAreaInterpolate(pointX, pointY0, pointY1){

            const domain = d3.range(0, 1, 1/(pointX.length-1));
            domain.push(1);

            const interpolateX = d3.scaleLinear()
                                    .domain(domain)
                                    .range(pointX);

            const interpolateY0 = d3.scaleLinear()
                                    .domain(domain)
                                    .range(pointY0);

             const interpolateY1 = d3.scaleLinear()
                                    .domain(domain)
                                    .range(pointY1);
            return {
                x: interpolateX,
                y0: interpolateY0,
                y1: interpolateY1
            };

        }

    }

    /* ----------------------------渲染坐标轴------------------------  */
    chart.renderX = function(){
        chart.svg().insert('g','.body')
                .attr('transform', 'translate(' + chart.bodyX() + ',' + (chart.bodyY() + chart.getBodyHeight()) + ')')
                .attr('class', 'xAxis') 
                .call(d3.axisBottom(chart.scaleX))
                    .selectAll("text")  
                    .style("text-anchor", "end")
                    .attr("dx", "-.8em")
                    .attr("dy", ".15em")
                    .attr("transform", "rotate(-65)")
                    .attr('fill', config.textColor);
    }

    chart.renderY = function(){
        chart.svg().insert('g','.body')
                .attr('transform', 'translate(' + chart.bodyX() + ',' + chart.bodyY() + ')')
                .attr('class', 'yAxis')
                .call(d3.axisLeft(chart.scaleY))
                    .selectAll("text")
                    .attr('fill', config.textColor);
    }

    chart.renderAxis = function(){
        chart.renderX();
        chart.renderY();
    }

    /* ----------------------------渲染文本标签------------------------  */
    chart.renderText = function(){
        d3.select('.xAxis').append('text')
                            .attr('class', 'axisText')
                            .attr('x', chart.getBodyWidth())
                            .attr('y', 0)
                            .attr('fill', config.textColor)
                            .attr('dy', 40)
                
        d3.select('.xAxis').selectAll('text')
        .on('mouseover', function(d){
            const e = d3.event;
            e.target.style.cursor = 'hand'
            d3.select(e.target)
                .attr('fill', config.hoverColor)
                .attr('transform', 'rotate(-65) scale(1.3)')
            
            d3.selectAll(`.date-${d}`)
                .attr('fill', 'white');
                
            proxyPoint.year = d
            // console.log(d,123456)
        })
        .on('mouseleave', function(d){
            const e = d3.event;
            d3.select(e.target)
                .attr('fill', 'white')
                .attr('transform', 'rotate(-65) scale(1)')

            d3.selectAll(`.date-${d}`)
                .attr('fill', 'white');
            // console.log(d,123457)
        })

        d3.select('.yAxis').append('text')
                            .attr('class', 'axisText')
                            .attr('x', 0)
                            .attr('y', 0)
                            .attr('fill', 'config.textColor')
                            .attr('transform', 'rotate(-90)')
                            .attr('dy', -40)
                            .attr('text-anchor','end')
    }

    /* ----------------------------渲染网格线------------------------  */
    chart.renderGrid = function(){
        d3.selectAll('.yAxis .tick')
            .each(function(d, i){
                if (config.ShowGridY.indexOf(d) > -1){
                    d3.select(this).append('line')
                        .attr('class','grid')
                        .attr('stroke', config.gridColor)
                        .attr('x1', 0)
                        .attr('y1', 0)
                        .attr('x2', chart.getBodyWidth())
                        .attr('y2', 0);
                }
            });

        d3.selectAll('.xAxis .tick')
            .each(function(d, i){
                if (config.ShowGridX.indexOf(d) > -1){
                    d3.select(this).append('line')
                        .attr('class','grid')
                        .attr('stroke', config.gridColor)
                        .attr('x1', 0)
                        .attr('y1', 0)
                        .attr('x2', 0)
                        .attr('y2', -chart.getBodyHeight());
                }
            });
        
            d3.selectAll('.domain')
                .attr('stroke', config.textColor)
            
            d3.selectAll('.xaxis .tick line')
                .attr('stroke', config.textColor)

            d3.selectAll('.yaxis .tick line')
                .attr('stroke', config.textColor)
    }

    /* ----------------------------渲染图标题------------------------  */
    chart.renderTitle = function(){
        chart.svg().append('text')
                .classed('title', true)
                .attr('x', chart.width()/2)
                .attr('y', 0)
                .attr('dy', '2em')
                .text(config.title)
                .attr('fill', config.textColor)
                .attr('text-anchor', 'middle')
                .attr('stroke', config.textColor);

    }

    /* ----------------------------绑定鼠标交互事件------------------------  */
    chart.addMouseOn = function(){
        //防抖函数
        function debounce(fn, time){
            let timeId = null;
            return function(){
                const context = this;
                const event = d3.event;
                timeId && clearTimeout(timeId)
                timeId = setTimeout(function(){
                    d3.event = event;
                    fn.apply(context, arguments);
                }, time);
            }
        }

        d3.selectAll('.point')
            .on('mouseover', function(d){
                const e = d3.event;
                const position = d3.mouse(chart.svg().node());
                e.target.style.cursor = 'hand'
                
                if(proxyPoint.year !== d.data.date) proxyPoint.year = d.data.date
                let state = d3.select(this).attr('value').split(':')[0]
                if(proxyPoint.state !== state) proxyPoint.state = state

                // console.log(d.data.date)

                d3.select(e.target)
                    .attr('fill', config.hoverColor);
                
                chart.svg()
                    .append('text')
                    .classed('tip', true)
                    .attr('x', position[0]-45)
                    .attr('y', position[1])
                    .attr('fill', config.textColor)
                    .text(() => {
                        // console.log(d3.select(this).attr('value'))
                        return d3.select(this).attr('value');
                    })
            })
            .on('mouseleave', function(d){
                const e = d3.event;
                
                d3.select(e.target)
                    .attr('fill', config.pointColor);
                
                d3.selectAll(`.date-${d.data.date}`)
                    .attr('fill', config.pointColor);
                    
                d3.select('.tip').remove();
            })
            .on('mousemove', debounce(function(){
                    const position = d3.mouse(chart.svg().node());
                    d3.select('.tip')
                    .attr('x', position[0]-45)
                    .attr('y', position[1]-5);
                }, 6)
            );
    }
        
    chart.render = function(){

        chart.renderAxis();

        chart.renderText();

        chart.renderGrid();

        chart.renderLines();

        chart.renderPonits();

        chart.renderTitle();

        chart.addMouseOn();

        chart.renderArea();
    }

    chart.renderChart();
    
        
});


var extractYearData = function(data, year) {
    sampleData = {};
    let tmp = data.filter((item)=> parseInt(item['year']) === year)
    tmp.sort((num1, num2) => {
        return num2['total_value'] - num1['total_value']
    })
    
    let tmp_max = tmp[0].total_value
    // console.log(tmp, tmp_max)
    
    let state_arr = ["HI", "AK", "FL", "SC", "GA", "AL", "NC", "TN", "RI", "CT", "MA",
    "ME", "NH", "VT", "NY", "NJ", "PA", "DE", "MD", "WV", "KY", "OH", 
    "MI", "WY", "MT", "ID", "WA", "DC", "TX", "CA", "AZ", "NV", "UT", 
    "CO", "NM", "OR", "ND", "SD", "NE", "IA", "MS", "IN", "IL", "MN", 
    "WI", "MO", "AR", "OK", "KS", "LS", "VA"]
        state_arr.forEach(function(d){
            let now = tmp.filter((item)=>item['state'] === d)[0]
            let initColor = '#0000FF', finalColor = '#00B9FF'
            if(now) {
                now = now['total_value']
                let ratio = (now - 0)/tmp_max
                // console.log(ratio)
                if(ratio < 0.1){
                    // console.log(ratio)
                    initColor = "#0000FF"
                    finalColor = "#00B9FF"
                    ratio = ratio/0.1
                }
                else if(ratio < 0.15){
                    // console.log(ratio)
                    initColor = "#03FCF5"
                    finalColor = "#B8FC03"
                    ratio = ratio/0.15
                }
                else if(ratio < 0.20){
                    // console.log(ratio)
                    initColor = "#F5FC03"
                    finalColor = "#FC9803"
                    ratio = ratio/0.2
                }
                else if (ratio < 0.4){
                    // console.log(ratio)
                    initColor = "#FD7903"
                    finalColor = "#F58F59"
                    ratio = ratio/0.4
                }
                else if (ratio < 0.7){
                    // console.log(ratio)
                    initColor = "#FD7903"
                    finalColor = "#F75000"
                    ratio = ratio/0.4
                }
                else{
                    // console.log(ratio)
                    initColor = "#FD7903"
                    finalColor = "#FF0000"
                }
                // console.log(ratio, initColor, finalColor)
                sampleData[d]={
                    val: parseInt(now), 
                    color:d3.interpolate(initColor, finalColor)(ratio)
                }
            }
            else{
                sampleData[d]={
                    val: 0, 
                    color:d3.interpolate("#CCCCCC", "#EEEEEE")(0)
                }
            }
    });
    return sampleData
}

var sampleData = {};  /* Sample random data. */	
d3.csv("./train_m.csv", function(d) {
    return d
}).then((data)=>{
    
    mapData = data;
    sampleData = extractYearData(data, 2019)
    
    /* draw states on id #statesvg */	
    uStates.draw("#statesvg", sampleData, proxyPoint);

    d3.select(self.frameElement).style("height", "300px");

});

function drawRiver() {
    d3.csv('./data.csv', function(d){
        if(d.state === point_data.state){
            return {
                date: d.date,
                state: d.state,
                buses: +d.buses,
                passengers: +d.passengers,
                pedestrians: +d.pedestrians,
                railway: +d.railway,
                trucks: +d.trucks,
                personal_vehicles: +d.personal_vehicles
            };
        }
        else return null
    }).then(function(data){
        console.log(data)
        /* ----------------------------配置参数------------------------  */
        const chart1 = new Chart1();
        const config = {
            margins: {top: 80, left: 80, bottom: 50, right: 80},
            textColor: 'white',
            gridColor: 'white',
            title: 'theme River of transport measure',
            animateDuration: 1000
        }
    
        chart1.margins(config.margins);
    
        /* ----------------------------尺度转换------------------------  */
        chart1.scaleX = d3.scaleTime()
                        .domain([new Date(data[0].date), new Date(data[data.length-1].date)])
                        .range([0, chart1.getBodyWidth()]);
    
        chart1.scaleY = d3.scaleLinear()
                        .domain([0, 400])
                        .range([chart1.getBodyHeight(), 0])
    
        chart1.stack = d3.stack()
                        .keys(['buses', 'passengers', 'pedestrians', 'railway', 'trucks', 'personal_vehicles'])
                        .order(d3.stackOrderInsideOut)
                        .offset(d3.stackOffsetWiggle);
    
        /* ----------------------------渲染面------------------------  */
        chart1.renderArea = function(){
            const areas = chart1.body().insert('g',':first-child')
                            .attr('transform', 'translate(0, -' +  d3.max(data, (d) => {
                                let tmp = JSON.parse(JSON.stringify(data[0]))
                                tmp.date = null
                                console.log((400 - d3.mean(Object.values(tmp)))/3)
                                return (400 - d3.mean(Object.values(tmp)))/2/2.5 + ')'
                            }))   // 使流图的位置处于Y轴中部
                            .selectAll('.river-area')
                            .data(chart1.stack(data));
    
                  areas.enter()
                            .append('path')
                            .attr('class', (d) => 'river-area river-area-' + d.key)
                        .merge(areas)
                            .style('fill', (d,i) => {
                                return chart1._colors(i)
                            })
                            .transition().duration(config.animateDuration)
                            .attrTween('d', areaTween);
    
            //中间帧函数
            function areaTween(_d){
                if (!_d) return;
                const generateArea = d3.area()
                            .x((d) => {
                                return d[0]
                            })
                            .y0((d) => d[1])
                            .y1((d) => d[2])
                            .curve(d3.curveCardinal.tension(0));
    
                const pointX = data.map((d) => chart1.scaleX(new Date(d.date)));
                const pointY0 = _d.map((d) => chart1.scaleY(d[0]));
                const pointY1 = _d.map((d) => chart1.scaleY(d[1]));
    
                const interpolate = getAreaInterpolate(pointX, pointY0, pointY1);
    
                const ponits = [];
    
                return function(t){
                    ponits.push([interpolate.x(t), interpolate.y0(t), interpolate.y1(t)]);
                    return generateArea(ponits);
                }
            }
    
            //点插值
            function getAreaInterpolate(pointX, pointY0, pointY1){
    
                const domain = d3.range(0, 1, 1/(pointX.length-1));
                domain.push(1);
    
                const interpolateX = d3.scaleLinear()
                                        .domain(domain)
                                        .range(pointX);
    
                const interpolateY0 = d3.scaleLinear()
                                        .domain(domain)
                                        .range(pointY0);
    
                 const interpolateY1 = d3.scaleLinear()
                                        .domain(domain)
                                        .range(pointY1);
                return {
                    x: interpolateX,
                    y0: interpolateY0,
                    y1: interpolateY1
                };
    
            }
    
        }
    
        /* ----------------------------渲染坐标轴------------------------  */
        chart1.renderX = function(){
            chart1.svg().insert('g','.body')
                    .attr('transform', 'translate(' + chart1.bodyX() + ',' + (chart1.bodyY() + chart1.getBodyHeight()) + ')')
                    .attr('class', 'xAxis')
                    .call(d3.axisBottom(chart1.scaleX)
                    .ticks(d3.timeYear.every(3)).tickFormat((d) => {
                        // console.log(d,11)
                        // console.log(d3.timeFormat("%Y")(d))
                        return d3.timeFormat("%Y")(d)
                    }))
                    .selectAll("text")
                    .attr('fill', config.textColor);
        }
    
        chart1.renderY = function(){
            chart1.svg().insert('g','.body')
                    .attr('transform', 'translate(' + chart1.bodyX() + ',' + chart1.bodyY() + ')')
                    .attr('class', 'yAxis')
                    .call(d3.axisLeft(chart1.scaleY))
                    .selectAll("text")
                    .attr('fill', config.textColor);;
        }
    
        chart1.renderAxis = function(){
            chart1.renderX();
            chart1.renderY();
        }
    
        /* ----------------------------渲染文本标签------------------------  */
        chart1.renderText = function(){
            d3.select('.xAxis').append('text')
                                .attr('class', 'axisText')
                                .attr('x', chart1.getBodyWidth())
                                .attr('y', 0)
                                .attr('fill', config.textColor)
                                .attr('dy', 40)
    
            d3.select('.yAxis').append('text')
                                .attr('class', 'axisText')
                                .attr('x', 0)
                                .attr('y', 0)
                                .attr('fill', config.textColor)
                                .attr('transform', 'rotate(-90)')
                                .attr('dy', -40)
                                .attr('text-anchor','end')
            d3.selectAll('.domain')
                .attr('stroke', config.textColor)
            
            d3.selectAll('.xaxis .tick line')
                .attr('stroke', config.textColor)
    
            d3.selectAll('.yaxis .tick line')
                .attr('stroke', config.textColor)
        }
    
        /* ----------------------------渲染网格线------------------------  */
        chart1.renderGrid = function(){
            d3.selectAll('.xAxis .tick')
                .append('line')
                .attr('class','grid')
                .attr('stroke', config.gridColor)
                .attr('stroke-dasharray', '10,10')
                .attr('x1', 0)
                .attr('y1', 0)
                .attr('x2', 0)
                .attr('y2', -chart.getBodyHeight());
        }
    
        /* ----------------------------渲染图标题------------------------  */
        chart1.renderTitle = function(){
            chart1.svg().append('text')
                    .classed('title', true)
                    .attr('x', chart1.width()/2)
                    .attr('y', 0)
                    .attr('dy', '2em')
                    .text(config.title)
                    .attr('fill', config.textColor)
                    .attr('text-anchor', 'middle')
                    .attr('stroke', config.textColor);
    
        }
    
        /* ----------------------------绑定鼠标交互事件------------------------  */
        chart1.addMouseOn = function(){
            //防抖函数
            function debounce(fn, time){
                let timeId = null;
                return function(){
                    const context = this;
                    const event = d3.event;
                    timeId && clearTimeout(timeId)
                    timeId = setTimeout(function(){
                        d3.event = event;
                        fn.apply(context, arguments);
                    }, time);
                }
            }
    
            d3.selectAll('.river-area')
                .on('mouseover', function(d){
                    const e = d3.event;
                    const position = d3.mouse(chart1.svg().node());
                    e.target.style.cursor = 'hand'
    
                    d3.selectAll('.river-area')
                        .attr('fill-opacity', 0.3);
    
                    d3.select(e.target)
                        .attr('fill-opacity', 1);
    
                    chart1.svg()
                        .append('text')
                        .classed('tip', true)
                        .attr('x', position[0]+5)
                        .attr('y', position[1])
                        .attr('fill', config.textColor)
                        .text(d.key);
                })
                .on('mouseleave', function(){
                    const e = d3.event;
    
                    d3.selectAll('.river-area')
                        .attr('fill-opacity', 1);
    
                    d3.select('.tip').remove();
                })
                .on('mousemove', debounce(function(){
                        const position = d3.mouse(chart1.svg().node());
                        d3.select('.tip')
                        .attr('x', position[0]+5)
                        .attr('y', position[1]-5);
                    }, 6)
                );
        }
    
        chart1.render = function(){
    
            chart1.renderAxis();
    
            chart1.renderText();
    
            // chart.renderGrid();
    
            chart1.renderTitle();
    
            chart1.renderArea();
    
            chart1.addMouseOn();
        }
    
        chart1.renderChart();
    
    
    });
}

drawRiver()













