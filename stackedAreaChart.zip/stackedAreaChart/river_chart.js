export default class Chart {
    constructor(){
        this._width = 600;
        this._height = 350;
        this._margins = {top:30, left:30, right:30, bottom:30};
        this._data = [];
        this._scaleX = null;
        this._scaleY = null;
        this._colors = d3.scaleOrdinal(d3.schemeCategory10);
        this._riverBox = null;
        this._river = null;
        this._body = null;
    }

    width(w){
        if (arguments.length === 0) return this._width;
        this._width = w;
        return this;
    }

    height(h){
        if (arguments.length === 0) return this._height;
        this._height = h;
        return this;
    }

    margins(m){
        if (arguments.length === 0) return this._margins;
        this._margins = m;
        return this;
    }

    data(d){
        if (arguments.length === 0) return this._data;
        this._data = d;
        return this;
    }

    scaleX(x){
        if (arguments.length === 0) return this._scaleX;
        this._scaleX = x;
        return this;
    }

    scaleY(y){
        if (arguments.length === 0) return this._scaleY;
        this._scaleY = y;
        return this;
    }

    svg(s){
        if (arguments.length === 0) return this._river;
        this._river = s;
        return this;
    }

    body(b){
        if (arguments.length === 0) return this._body;
        this._body = b;
        return this;
    }

    box(b){
        if (arguments.length === 0) return this._riverBox;
        this._riverBox = b;
        return this;
    }

    getBodyWidth(){
        let width = this._width - this._margins.left - this._margins.right;
        return width > 0 ? width : 0;
    }

    getBodyHeight(){
        let height = this._height - this._margins.top - this._margins.bottom;
        return height > 0 ? height : 0;
    }

    defineBodyClip(){
        const padding = 10;

        this._river.append('defs')
                 .append('clipPath')
                 .attr('id', 'clip')
                 .append('rect')
                 .attr('width', this.getBodyWidth() + padding * 2)
                 .attr('height', this.getBodyHeight() + padding * 2)
                 .attr('x', -padding)
                 .attr('y', -padding);
    }

    render(){
        return this;
    }

    bodyX(){
        return this._margins.left;
 
    }

    bodyY(){
        return this._margins.top;
    }

    renderBody(){
        if (!this._body){
            this._body = this._river.append('g')
                            .attr('class', 'river-body')
                            .attr('transform', 'translate(' + this.bodyX() + ',' + this.bodyY() + ')')
                            .attr('clip-path', "url(#clip)");
        }

        this.render();
    }

    renderChart(){
        if (!this._riverBox){
            this._riverBox = d3.select('body')
                            .append('div')
                            .attr('class','riverBox')
                            .attr('width', '600px')
                            .attr('height', '350px');
        }

        if(!this._river){
            this._river= this._riverBox.append('svg')
            .attr('width', this._width)
            .attr('height', this._height)
            .attr("preserveAspectRatio", "xMidYMid meet")
            .attr("viewBox", "0 0 600 350")
        }

        this.defineBodyClip();

        this.renderBody();
    }

}

